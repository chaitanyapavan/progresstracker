#include <iostream>
#include <vector>
#include <cmath>

using namespace std;



int main(){
	int t; cin >> t;
	while(t--){
		int n,m,xk,yk; cin >>n >>m >>xk >>yk; int ans=0;
		for(int i=1; i<=n; ++i){
			for(int j=1; j<=m; ++j){
				if( i== xk && y==yk){
					continue;
				}
				int x1, y1, x2, y2, x3, y3, x4, y4;
				int yleft_top = y+(i-1); 
				int yleft_bottom = y -(i-1);
				int yright_top = y+(n+1-1);
				int yright_bottom = y-(n+1-1);
				int xleft_top = x -(m+1-j);
				int xleft_bottom = x -(j-1);
				int xright_top = x + (m+1-j);
				int xright_bottom = x - (j-1);
				if(yleft_top > m){
					x1 = xleft_top;
					y1 = m;
				}
				else{
					x1 = 1;
					y1 = yleft_top;
				}
				if(yleft_bottom < 1){
					x4 = xleft_bottom;
					y4 = 1;
				}
				else{
					x4 = 1;
					y4 = yleft_bottom;
				}
				if(yright_top > m){
					x3 = xright_top;
					y3 = m;
				}
				else{
					x3 = 1;
					y3 = yright_top;
				}
				if(yright_bottom < 1){
					x2 = xright_bottom;
					y2 = 1;
				}
				else{
					x2 = 1;
					y2 = yright_bottom;
				}
				int bad = abs(x1-x2) + abs(x3 -x4) + n + m;
				if(((xk-1)/(yk-1)) == 1){
					if(xk < i){
						bad -= abs(xk-x1);
					}
					else{
						bad -= abs(x2-xk);
					}
				}
				else if(((xk-1)/(yk-1)) == -1){
					if(xk < i){
						bad -= abs(xk -x4);
					}
					else{
						bad -= abs(x3 - xk);
					}
				}
				else if(i == xk){
					if(j < yk){
						bad -= abs(yk-1);
					}
					else{
						bad -= abs(m-yk);
					}
				}
				else if(j == yk){
					if(i < xk){
						bad -= abs(xk-1);
					}
					else{
						bad -= abs(n-xk);
					}
				}
				else{
					bad += 1;
				}
				int good = n*m - bad;
				cout << good << endl;
			}
		}
	}
}