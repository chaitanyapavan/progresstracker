from django.db import models
import datetime
from django.utils import timezone
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import User
#from django.contrib.postgres.fields import ArrayField

class Session(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    session_id = models.CharField(max_length=200)
    session_active = models.IntegerField(default=0)
    def deactivate(self):
        session_active = 0
    def activate(self):
        session_active = 1
    def __str__(self):
        return self.session_id

class Question(models.Model):
    question_text = models.CharField(max_length=200)
    session = models.ForeignKey(Session, on_delete=models.CASCADE)
    pub_date = models.DateTimeField('date published') 
    def __str__(self):
        return self.question_text
    def was_published_recently(self):
        return self.pub_date >= timezone.now() - datetime.timedelta(days=1)

class Checkpoint(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    checkpoint_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=10)
    def __str__(self):
        return self.checkpoint_text

class User(models.Model):
    user_id = models.CharField(max_length=200)
    session = models.ForeignKey(Session, on_delete=models.CASCADE)
    user_password = models.CharField(max_length=200)
    def __str__self():
        return self.user_id

# class User1(AbstractUser):
#     is_student = models.BooleanField('student status', default=False)
#     is_teacher = models.BooleanField('teacher status', default=False)

class MyModel(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    session = models.ForeignKey(Session, on_delete=models.CASCADE)
    checkpoint = models.ForeignKey(Checkpoint, on_delete=models.CASCADE)
    yes = models.IntegerField(default=0)

class Comment(models.Model):
    checkpoint = models.ForeignKey(Checkpoint, on_delete=models.CASCADE)
    comment_text = models.CharField(max_length=200)
    def __str__(self):
        return self.comment_text

class Ping(models.Model):
    checkpoint = models.ForeignKey(Checkpoint, on_delete=models.CASCADE)
    ping_text = models.CharField(max_length=200)
    resolved = models.IntegerField(default=0)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    reply_text = models.CharField(max_length=200, default='')
    def __str__(self):
        return self.ping_text
    