from django.urls import include, path
from django.conf.urls import url
from . import views
from rest_framework import routers, serializers, viewsets, generics
from rest_framework.views import APIView
from polls.models import Question
from polls.models import Checkpoint, Session, User, MyModel, Ping
from django.shortcuts import render, redirect
import csv
from django.template import loader
from django.shortcuts import get_object_or_404
from django.core.management import call_command
from django.http import HttpResponse, HttpResponseRedirect
from rest_framework.response import Response
from rest_framework.decorators import action
from itertools import chain


class questionSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Question
        fields=('question_text',)
class CheckpointSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Checkpoint
        fields=('question','checkpoint_text','votes',)
class MyModelSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = MyModel
        fields = ('checkpoint','yes')
class PingSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Ping
        fields = ('ping_text', 'reply_text')

class PingViewSet(viewsets.ModelViewSet):
    serializer_class=PingSerializer
    def get_queryset(self):
        try:
            username = self.kwargs['user']
            password = self.kwargs['password']
            sessid = self.kwargs['session_id']
            qid = self.kwargs['question']
            cno = self.kwargs['checkpoint']
            s1 = Session.objects.get(id=int(sessid))
            s1 = s1.user_set.get(user_id=username)
            if not s1.user_password==password:
                return HttpResponse('hoo')
            sess = Session.objects.filter(id=self.kwargs['session_id'])
            h2 = sess[0].question_set.all()
            s = h2[int(qid)]
            #s = Question.objects.get(id=int(qid))
            h = s.checkpoint_set.all()
            c = h[int(cno)]
            pingset = Ping.objects.all()
            q = Ping.objects.filter(id=-1)
            for i in range(len(pingset)):
                j = pingset.filter(id=i+1)
                if (j[0].checkpoint == c) and (j[0].user == s1):
                    q = q | j
            return q
        except:
            return HttpResponse('hoo')

class MyModelViewSet(viewsets.ModelViewSet):
    serializer_class=MyModelSerializer
    def get_queryset(self):
        try:
            username = self.kwargs['user']
            password = self.kwargs['password']
            sessid = self.kwargs['session_id']
            s1 = Session.objects.get(id=int(sessid))
            s1 = s1.user_set.get(user_id=username)
            if not s1.user_password==password:
                return HttpResponse('hoo')
            s = Session.objects.filter(id=self.kwargs['session_id'])
            myModellist = MyModel.objects.all()
            q = MyModel.objects.filter(id=-1)
            l = []
            for j in range(len(myModellist)):
                i = MyModel.objects.filter(id=j+1)
                if (i[0].user == s1) and (i[0].session == s[0]):
                    q = q | i
            return q
        except:
            return HttpResponse('hoo')


class CheckpointViewSet(viewsets.ModelViewSet):
    #queryset=Checkpoint.objects.all()
    serializer_class=CheckpointSerializer
    queryset=Checkpoint.objects.all()

class questionViewSet(viewsets.ModelViewSet):
    #session = Session.objects.filter(session_id = session_id)
    #queryset=Question.objects.filter(session = session)
    #session_id = request.POST['session_id']
    queryset=Question.objects.all()
    serializer_class=questionSerializer

    # def get_queryset(self):
    #     #user = self.request.user
    #     books = Question.objects.filter(session=self.kwargs['session_id'])
    #     return books



# class CheckpointViewSet(APIview):

#     def get(self, request):
#         queryset=Checkpoint.objects.all()
#         serializer = CheckpointSerializer(queryset, many=True)
#         return Response(serializer.data)

# class questionViewSet(APIview):

#     def get(self, request):
#         queryset=Question.objects.all()
#         serializer = questionSerializer(queryset, many=True)
#         return Response(serializer.data)

router=routers.DefaultRouter()

router.register(r'questions',questionViewSet)
router.register(r'checkpoints',CheckpointViewSet)
#router.register(r'questions/(?P<session_id>[0-9]+)',questionViewSet, base_name='books')
router.register(r'myModels/(?P<session_id>[0-9]+)/(?P<user>.*)/(?P<password>.*)',MyModelViewSet, base_name='q')
router.register(r'pings/(?P<session_id>[0-9]+)/(?P<user>.*)/(?P<password>.*)/(?P<question>[0-9]+)/(?P<checkpoint>[0-9]+)',PingViewSet, base_name='q')

# urlpatterns = [
#     path('index', views.index, name='index'),
#     path('<int:question_id>/', views.detail, name='detail'),
#     path('<int:question_id>/results/', views.results, name='results'),
#     path('<int:question_id>/vote/', views.vote, name='vote'),
#     path('new',views.new,name='new'),
#     path('<int:question_id>/newcheckpoint', views.newcheckpoint, name='newcheckpoint' ),
#     path('login/', views.login1, name='login'),
#     path('loginn/', views.loginn, name='loginn'),
#     path('logout1/', views.logout1, name='logout1'),
#     path('addstudentfile/', views.addstudentfile, name='addstudentfile'),
#     path('addstudent/', views.addstudent, name="addstudent"),
#     path('check_user', views.check_user, name="check_user"),
#     url(r'^',include(router.urls)),
# ]

urlpatterns = [
	path('login/', views.login1, name='login'),
    path('loginn/', views.loginn, name='loginn'),
    path('logout1/', views.logout1, name='logout1'),
    path('session/', views.session, name='session'),
    path('deactivate_session', views.deactivate_session, name='deactivate_session'),
    path('activate_session', views.activate_session, name='activate_session'),
    path('delete_session', views.delete_session, name='delete_session'),
    #path('delete_all_sessions', views.delete_all_sessions, name='delete_all_sessions'),
    path('studentquestion/', views.studentquestion, name='studentquestion'),
    path('studentquestion1/<int:session_id>/', views.studentquestion1, name='studentquestion1'),
    path('student/<int:session_id>/', views.student, name='student'),
    path('question/<int:session_id>/', views.question, name='question'),
    path('<int:session_id>/questioncheckpoint/<int:question_id>/', views.checkpoint, name='checkpoint'),
    path('<int:session_id>/questioncheckpoint/<int:question_id>/<int:checkpoint_id>/', views.checkpoint1, name='checkpoint1'),
    path('addstudentfile/<int:session_id>/', views.addstudentfile, name='addstudentfile'),
    path('addstudent/<int:session_id>/', views.addstudent, name="addstudent"),
    path('newquestion/<int:session_id>/', views.newquestion, name="newquestion"),
    path('question/<int:question_id>/newcheckpoint/<int:session_id>/', views.newcheckpoint, name='newcheckpoint'),
    path('check_user/', views.check_user, name="check_user"),
    path('check_session', views.check_session, name='check_session'),
    path('vote_increase', views.vote_increase, name='vote_increase'),
    path('vote_decrease', views.vote_decrease, name='vote_decrease'),
    path('add_comment', views.add_comment, name='add_comment'),
    path('add_ping', views.add_ping, name='add_ping'),
    path('gotoquestion/<int:session_id>/', views.gotoquestion, name='gotoquestion'),
    path('gobackstudentquestion/<int:session_id>/', views.goback1, name='goback1'),
    path('gobacksession/', views.goback2, name='goback2'),
    path('gobackcheckpoint/<int:session_id>/<int:question_id>/', views.goback3, name='goback3'),
    path('markasdone/<int:ping_id>/<int:session_id>/<int:question_id>/<int:checkpoint_id>/', views.markasdone, name='mark as done'),
    path('statistics/<int:session_id>/<int:question_id>/', views.statistics, name = 'statistics'),
    url(r'^',include(router.urls)),
    #url(r'questions',views.questionViewSet.as_view()),
    #url(r'checkpoints',views.CheckpointViewSet.as_view()),
]
