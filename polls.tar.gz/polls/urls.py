from django.urls import include, path
from django.conf.urls import url
from . import views
from rest_framework import routers, serializers, viewsets, generics
from polls.models import Question
from polls.models import Checkpoint

class questionSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Question
        fields=('question_text',)
class CheckpointSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Checkpoint
        fields=('question','checkpoint_text','votes',)
class CheckpointViewSet(viewsets.ModelViewSet):
    queryset=Checkpoint.objects.all()
    serializer_class=CheckpointSerializer
class questionViewSet(viewsets.ModelViewSet):
    queryset=Question.objects.all()
    serializer_class=questionSerializer
router=routers.DefaultRouter()
router.register(r'questions',questionViewSet)
router.register(r'checkpoints',CheckpointViewSet)


# urlpatterns = [
#     path('index', views.index, name='index'),
#     path('<int:question_id>/', views.detail, name='detail'),
#     path('<int:question_id>/results/', views.results, name='results'),
#     path('<int:question_id>/vote/', views.vote, name='vote'),
#     path('new',views.new,name='new'),
#     path('<int:question_id>/newcheckpoint', views.newcheckpoint, name='newcheckpoint' ),
#     path('login/', views.login1, name='login'),
#     path('loginn/', views.loginn, name='loginn'),
#     path('logout1/', views.logout1, name='logout1'),
#     path('addstudentfile/', views.addstudentfile, name='addstudentfile'),
#     path('addstudent/', views.addstudent, name="addstudent"),
#     path('check_user', views.check_user, name="check_user"),
#     url(r'^',include(router.urls)),
# ]

urlpatterns = [
	path('login/', views.login1, name='login'),
    path('loginn/', views.loginn, name='loginn'),
    path('logout1/', views.logout1, name='logout1'),
    path('session/', views.session, name='session'),
    path('deactivate_session', views.deactivate_session, name='deactivate_session'),
    path('activate_session', views.activate_session, name='activate_session'),
    path('delete_session', views.delete_session, name='delete_session'),
    path('studentquestion/', views.studentquestion, name='studentquestion'),
    path('studentquestion1/', views.studentquestion1, name='studentquestion1'),
    path('student/', views.student, name='student'),
    path('question/', views.question, name='question'),
    path('question/<int:question_id>/', views.checkpoint, name='checkpoint'),
    path('addstudentfile/', views.addstudentfile, name='addstudentfile'),
    path('addstudent/', views.addstudent, name="addstudent"),
    path('newquestion/', views.newquestion, name="newquestion"),
    path('question/<int:question_id>newcheckpoint/', views.newcheckpoint, name='newcheckpoint'),
    path('check_user/', views.check_user, name="check_user"),
    path('check_session', views.check_session, name='check_session'),
    path('vote_increase', views.vote_increase, name='vote_increase'),
    path('vote_decrease', views.vote_decrease, name='vote_decrease'),
    url(r'^',include(router.urls)),
]
