from django.urls import path
from . import views



urlpatterns = [
    path('', views.index, name='index'),
    path('<int:question_id>/', views.detail, name='detail'),
    path('<int:question_id>/results/', views.results, name='results'),
    path('<int:question_id>/vote/', views.vote, name='vote'),
    path('new',views.new,name='new'),
    path('<int:question_id>/newcheckpoint', views.newcheckpoint, name='newcheckpoint' ),
    path('login/', views.login1, name='login'),
    path('loginn/', views.loginn, name='loginn'),
    path('logout1/', views.logout1, name='logout1'),
    path('addstudentfile/', views.addstudentfile, name='addstudentfile')
]
