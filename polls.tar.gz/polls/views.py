from django.shortcuts import render, redirect

from django.template import loader
from django.shortcuts import get_object_or_404

from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse

from .models import Question, Choice
from django.utils import timezone

def index(request):
    latest_question_list = Question.objects.all()
    context = {'latest_question_list': latest_question_list}
    return render(request, 'polls/index.html', context) 
 
def detail(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    return render(request, 'polls/details.html', {'question': question})

def results(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    return render(request, 'polls/results.html', {'question': question})

def vote(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    try:
        selected_choice = question.choice_set.get(pk=request.POST['choice'])
    except (KeyError, Choice.DoesNotExist):
        # Redisplay the question voting form.
        return render(request, 'polls/detail.html', {
            'question': question,
            'error_message': "You didn't select a choice.",
        })
    else:
        selected_choice.votes += 1
        selected_choice.save()
        # Always return an HttpResponseRedirect after successfully dealing
        # with POST data. This prevents data from being posted twice if a
        # user hits the Back button.
        return HttpResponse("Question"+str(question_id)+"created");
#def index1(request):
#	return HttpResponse("Hmm, This one is mine")

# Create your views here.
def new(request):
    q=Question(question_text=request.POST['newquestion'],pub_date=timezone.now())
    q.save()
    #return HttpResponse("Question "+str(q.id)+" created")
    return redirect('index')
    

def newcheckpoint(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    c = question.checkpoint_set.create(checkpoint_text = request.POST['newcheckpoint'])
    c.save()
    #return HttpResponse("Checkpoint "+str(c.pk)+" created")
    return redirect('detail', question_id=question_id)

def login(request):
    users = user.object.all();
