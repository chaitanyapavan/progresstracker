from django.shortcuts import render, redirect
import csv
from django.template import loader
from django.shortcuts import get_object_or_404
from django.core.management import call_command
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from .models import Question, Checkpoint, User, Session
from django.utils import timezone
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

#import sqlite3
#con = sqlite3.connect()

def login1(request):
    return render(request, 'polls/login.html')

def loginn(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        return redirect('session')
    else:
        return HttpResponse('You are not a registered user or password is wrong')

def logout1(request):
    logout(request)
    return redirect('login')

def session(request):
    session_list = Session.objects.all()
    return render(request, 'polls/session.html', {'session_list' : session_list})

def studentquestion(request):
    session_id = request.POST['session_id']
    try:
        s = Session.objects.get(session_active =1)
        return HttpResponse("Already a Session exists, delete that session to create new one")
    except:
        try:
            Session.objects.get(session_active =0)
            return HttpResponse("Already a Session exists, delete that session to create new one")
        except:
            s = Session(session_id=session_id, session_active=0)
            s.save()
            return render(request, 'polls/studentquestion.html')

def studentquestion1(request):
    return render(request, 'polls/studentquestion.html')

def student(request):
    user_list = User.objects.all()
    return render(request, 'polls/student.html', {'users_list' : user_list})

def addstudentfile(request):
    data = {}
    if "GET" == request.method:
        return render(request, "polls/index.html", data)
    csv_file = request.FILES["csv_file"]
    file_data = csv_file.read().decode("utf-8")
    lines = file_data.split("\n")
    for line in lines:
        if line=="":
            break
        fields = line.split("|")
        u=User(user_id=fields[0],user_password=fields[1])
        u.save()
    return redirect('student')

def addstudent(request):
    u=User(user_id=request.POST['student_id'],
        user_password=request.POST['student_password'])
    u.save()
    return redirect('student')

def question(request):
    latest_question_list = Question.objects.all()
    context = {'latest_question_list': latest_question_list}
    return render(request, 'polls/question.html', context)

def newquestion(request):
    if not request.user.is_authenticated:
        return redirect('login')
    q=Question(question_text=request.POST['newquestion'],pub_date=timezone.now())
    q.save()
    #return HttpResponse("Question "+str(q.id)+" created")
    return redirect('question')

def checkpoint(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    return render(request, 'polls/checkpoint.html', {'question': question})

def newcheckpoint(request, question_id):
    if not request.user.is_authenticated:
        return redirect('login')
    question = get_object_or_404(Question, pk=question_id)
    c = question.checkpoint_set.create(checkpoint_text = request.POST['newcheckpoint'], votes=0)
    c.save()
    #return HttpResponse("Checkpoint "+str(c.pk)+" created")
    return redirect('checkpoint', question_id=question_id)

def check_user(request):
    sid = request.GET['student_id']
    spwd = request.GET['student_password']
    try:
        s = User.objects.get(user_id=sid)
        if s.user_password==spwd:
            return HttpResponse('true')
        else:
            return HttpResponse("false")
    except:
        return HttpResponse("false")

def check_session(request):
    sess = request.GET['session_id']
    try:
        s = Session.objects.get(session_id=sess)
        if s.session_active==1:
            return HttpResponse('Cool session is active')
        else:
            return HttpResponse('Session not active')
    except:
        return HttpResponse("Session name doesn't exist")

def vote_increase(request):
    qid = request.GET['question_id']
    cno = request.GET['checkpoint_number']
    try:
        s = Question.objects.get(id=int(qid))
        h = s.checkpoint_set.all()
        c = h[int(cno)]
        #c = Checkpoint.objects.get(id=x)
        c.votes += 1
        c.save()
        return HttpResponse('true')
    except:
        return HttpResponse('false')

def vote_decrease(request):
    qid = request.GET['question_id']
    cno = request.GET['checkpoint_number']
    try:
        s = Question.objects.get(id=int(qid))
        h = s.checkpoint_set.all()
        x = h[int(cno)].id
        c = Checkpoint.objects.get(id=x)
        c.votes -= 1
        c.save()
        return HttpResponse('true')
    except:
        return HttpResponse('false')

def deactivate_session(request):
    try:
        sid = Session.objects.get(session_active=1)
        sid.session_active =0
        sid.save()
        return redirect('session')
    except:
        return HttpResponse("no active session")

def delete_session(request):
    call_command('migrate', 'polls', 'zero')
    #call_command('makemigrations')
    call_command('migrate', 'polls')
    return redirect('session')

def activate_session(request):
    try:
        q = Question.objects.get(id=1)
    except:
        return HttpResponse("Atleast one question should be added to make session active")
    try:
        c = Checkpoint.objects.get(id=1)
    except:
        return HttpResponse("Atleast one Checkpoint should be added to make session active")
    try:
        sid = Session.objects.get(session_active=0)
        sid.session_active = 1
        sid.save()
        return redirect('session')
    except:
        return HttpResponse('No inactive session to be activated')







