from django.shortcuts import render, redirect
import csv
from django.template import loader
from django.shortcuts import get_object_or_404
from django.core.management import call_command
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from .models import Question, Checkpoint, User, Session, Comment, Ping, MyModel
from django.utils import timezone
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
import matplotlib.pyplot as plt 
from rest_framework import routers, serializers, viewsets, generics
from rest_framework.views import APIView

#import sqlite3
#con = sqlite3.connect()

def login1(request):
    return render(request, 'polls/login.html')

def loginn(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        return redirect('session')
    else:
        return HttpResponse('You are not a registered user or password is wrong')

def logout1(request):
    logout(request)
    return redirect('login')

def session(request):
    if not request.user.is_authenticated:
        return redirect('login')
 
    user = request.user
    session_list = user.session_set.all()
    #session_list = Session.objects.filter()
    return render(request, 'polls/session.html', {'session_list' : session_list})

def studentquestion(request):
    if not request.user.is_authenticated:
        return redirect('login')
    session_id = request.POST['session_id']
    # try:
    #     s = Session.objects.get(session_active =1)
    #     return HttpResponse("Already a Session exists, delete that session to create new one")
    # except:
    #     try:
    #         Session.objects.get(session_active =0)
    #         return HttpResponse("Already a Session exists, delete that session to create new one")
    #     except:
    s = Session(session_id=session_id, session_active=0, author=request.user)
    s.save()
    return redirect( 'session')

def studentquestion1(request, session_id):
    if not request.user.is_authenticated:
        return redirect('login')
    session = get_object_or_404(Session, pk=session_id)
    return render(request, 'polls/studentquestion.html', {'session':session})

def student(request,session_id):
    if not request.user.is_authenticated:
        return redirect('login')
    session = get_object_or_404(Session, pk=session_id)
    user_list = session.user_set.all()
    return render(request, 'polls/student.html', {'users_list' : user_list, 'session' : session})

def addstudentfile(request,session_id):
    if not request.user.is_authenticated:
        return redirect('login')
    session = get_object_or_404(Session, pk=session_id)
    session_id = session.id
    data = {}
    if "GET" == request.method:
        return render(request, "polls/index.html", data)
    csv_file = request.FILES["csv_file"]
    file_data = csv_file.read().decode("utf-8")
    lines = file_data.split("\n")
    for line in lines:
        if line=="":
            break
        fields = line.split("|")
        u=session.user_set.create(user_id=fields[0],user_password=fields[1])
        u.save()
    #user_list = User.objects.all()
    #return render(request, 'polls/student.html', {'users_list' : user_list, 'session' : session})
    return redirect('student', session_id=session.id)

def addstudent(request,session_id):
    if not request.user.is_authenticated:
        return redirect('login')
    session = get_object_or_404(Session, pk=session_id)
    session_id = session.id
    u=session.user_set.create(user_id=request.POST['student_id'],
        user_password=request.POST['student_password'])
    u.save()
    questionlist = session.question_set.all()
    for i in questionlist:
        checkpointlist = i.checkpoint_set.all()
        for j in checkpointlist:
            x = MyModel(session=session, user=u, yes=0, checkpoint=j)
            x.save()
    #user_list = User.objects.all()
    #return render(request, 'polls/student.html', {'users_list' : user_list, 'session' : session})
    return redirect('student', session_id=session.id)


def question(request,session_id):
    if not request.user.is_authenticated:
        return redirect('login')
    session = get_object_or_404(Session, pk=session_id)
    session_id = session.id
    latest_question_list = session.question_set.all()
    context = {'latest_question_list': latest_question_list, 'session':session}
    return render(request, 'polls/question.html', context)

def newquestion(request, session_id):
    if not request.user.is_authenticated:
        return redirect('login')
    session = get_object_or_404(Session, pk=session_id)
    q=session.question_set.create(question_text=request.POST['newquestion'],pub_date=timezone.now())
    q.save()
    #return HttpResponse("Question "+str(q.id)+" created")
    #latest_question_list = Question.objects.all()
    #context = {'latest_question_list': latest_question_list, 'session':session}
    #return render(request, 'polls/question.html', context)
    return redirect('question', session_id=session.id)

def checkpoint(request, question_id, session_id):
    if not request.user.is_authenticated:
        return redirect('login')
    question = get_object_or_404(Question, pk=question_id)
    session = get_object_or_404(Session, pk=session_id)

    return render(request, 'polls/checkpoint.html', {'question': question, 'session':session})

def checkpoint1(request, question_id, session_id, checkpoint_id):
    if not request.user.is_authenticated:
        return redirect('login')
    question = get_object_or_404(Question, pk=question_id)
    session = get_object_or_404(Session, pk=session_id)
    checkpoint = get_object_or_404(Checkpoint, pk=checkpoint_id)
    set1 = checkpoint.ping_set.all().filter(resolved = 0)
    set2 = checkpoint.ping_set.all().filter(resolved = 1)
    return render(request, 'polls/checkpoint1.html', {'question': question, 'session':session,
        'checkpoint': checkpoint, 'set1': set1, 'set2' : set2})

def newcheckpoint(request, question_id, session_id):
    #if not request.user.is_authenticated:
     #   return redirect('login')
    session = get_object_or_404(Session, pk=session_id)
    question = get_object_or_404(Question, pk=question_id)
    c = question.checkpoint_set.create(checkpoint_text = request.POST['newcheckpoint'], votes=0)
    c.save()
    userlist = session.user_set.all()
    for i in userlist:
        x = MyModel(session=session, user=i, yes=0, checkpoint=c)
        x.save()
    #return HttpResponse("Checkpoint "+str(c.pk)+" created")
    return redirect('checkpoint', question_id=question_id, session_id=session_id)

def check_user(request):
    #if not request.user.is_authenticated:
     #   return redirect('login')
    sid = request.GET['student_id']
    spwd = request.GET['student_password']
    sessid = request.GET['session_id']
    try:
        s = Session.objects.get(id=int(sessid))
        s = s.user_set.get(user_id=sid)
        if s.user_password==spwd:
            return HttpResponse('true')
        else:
            return HttpResponse("false")
    except:
        return HttpResponse("false")

def check_session(request):
    #if not request.user.is_authenticated:
    #    return redirect('login')
    sess = request.GET['session_id']
    try:
        #user = request.user
        s = Session.objects.get(session_id=sess)
        if s.session_active==1:
            return HttpResponse('Cool session is active'+' '+str(s.id))
        else:
            return HttpResponse('Session not active')
    except:
        return HttpResponse("Session name doesn't exist")

def vote_increase(request):
    #if not request.user.is_authenticated:
     #   return redirect('login')
    qid = request.GET['question_id']
    cno = request.GET['checkpoint_number']
    sid = request.GET['session_id']
    uname = request.GET['user']
    try:
        sess = Session.objects.filter(id=int(sid))
        h2 = sess[0].question_set.all()
        s = h2[int(qid)]
        #s = Question.objects.get(id=int(qid))
        h = s.checkpoint_set.all()
        c = h[int(cno)]
        #c = Checkpoint.objects.get(id=x)
        c.votes += 1
        c.save()
        myModellist = MyModel.objects.all()
        s1 = sess[0].user_set.get(user_id=uname)
        for j in range(len(myModellist)):
            i = MyModel.objects.filter(id=j+1)
            if (i[0].user == s1) and (i[0].session == sess[0]) and (i[0].checkpoint==c):
                y = i[0]
                y.yes = 1
                y.save()
        # s1 = Session.objects.get(id=int(sid))
        # s1 = s1.user_set.get(user_id=uname)
        # m = MyModel.objects.get(user=s1 )
        return HttpResponse('true')
    except:
        return HttpResponse('false')

def vote_decrease(request):
    #if not request.user.is_authenticated:
     #   return redirect('login')
    qid = request.GET['question_id']
    cno = request.GET['checkpoint_number']
    sid = request.GET['session_id']
    uname = request.GET['user']
    try:
        sess = Session.objects.filter(id=int(sid))
        h2 = sess[0].question_set.all()
        s = h2[int(qid)]
        #s = Question.objects.get(id=int(qid))
        h = s.checkpoint_set.all()
        x = h[int(cno)].id
        c = Checkpoint.objects.get(id=x)
        c.votes -= 1
        c.save()
        myModellist = MyModel.objects.all()
        s1 = sess[0].user_set.get(user_id=uname)
        for j in range(len(myModellist)):
            i = MyModel.objects.filter(id=j+1)
            if (i[0].user == s1) and (i[0].session == sess[0]) and (i[0].checkpoint==c):
                y = i[0]
                y.yes = 0
                y.save()
        # s1 = Session.objects.get(id=int(sid))
        # s1 = s1.user_set.get(user_id=uname)
        return HttpResponse('true')
    except:
        return HttpResponse('false')

def add_comment(request):
    #if not request.user.is_authenticated:
     #   return redirect('login')
    qid = request.GET['question_id']
    cno = request.GET['checkpoint_number']
    ctxt = request.GET['text']
    sid = request.GET['session_id']
    if(ctxt==''):
        return HttpResponse('false')
    try:
        sess = Session.objects.filter(id=int(sid))
        h2 = sess[0].question_set.all()
        s = h2[int(qid)]
        #s = Question.objects.get(id=int(qid))
        h = s.checkpoint_set.all()
        c = h[int(cno)]
        x = c.comment_set.create(comment_text =ctxt)
        x.save()
        return HttpResponse('true')
    except:
        return HttpResponse('false')

def add_ping(request):
    #if not request.user.is_authenticated:
     #   return redirect('login')
    qid = request.GET['question_id']
    cno = request.GET['checkpoint_number']
    ctxt = request.GET['text']
    sid = request.GET['session_id']
    uname = request.GET['user']
    if(ctxt==''):
        return HttpResponse('false')
    try:
        sess = Session.objects.filter(id=int(sid))
        h2 = sess[0].question_set.all()
        s = h2[int(qid)]
        #s = Question.objects.get(id=int(qid))
        h = s.checkpoint_set.all()
        c = h[int(cno)]
        s1 = Session.objects.get(id=int(sid))
        s1 = s1.user_set.get(user_id=uname)
        x = c.ping_set.create(ping_text =ctxt, resolved = 0, user=s1)
        x.save()
        return HttpResponse('true')
    except:
        return HttpResponse('false')

def markasdone(request, ping_id, session_id, question_id, checkpoint_id):
    ping = Ping.objects.get(id=ping_id)
    reply_text = request.POST['reply']
    #x = -(ping.id)
    #reply_ping = Ping(checkpoint=ping.checkpoint, user=ping.user, resolved=x, ping_text=reply_text)
    #reply_ping.save()
    ping.reply_text = reply_text
    ping.resolved = 1
    ping.save()
    return redirect('checkpoint1', question_id=question_id, session_id=session_id, checkpoint_id=checkpoint_id)



# def deactivate_session(request):
#     try:
#         sid = Session.objects.get(session_active=1)
#         sid.session_active =0
#         sid.save()
#         return redirect('session')
#     except:
#         return HttpResponse("no active session")

#def delete_all_sessions(request):
 #   if not request.user.is_authenticated:
#        return redirect('login')
 #   call_command('migrate', 'polls', 'zero')
 #   #call_command('makemigrations')
 #   call_command('migrate', 'polls')
 #   return redirect('session')

# def activate_session(request):
#     try:
#         q = Question.objects.get(id=1)
#     except:
#         return HttpResponse("Atleast one question should be added to make session active")
#     try:
#         c = Checkpoint.objects.get(id=1)
#     except:
#         return HttpResponse("Atleast one Checkpoint should be added to make session active")
#     try:
#         sid = Session.objects.get(session_active=0)
#         sid.session_active = 1
#         sid.save()
#         return redirect('session')
#     except:
#         return HttpResponse('No inactive session to be activated')

def gotoquestion(request, session_id):
    if not request.user.is_authenticated:
        return redirect('login')
    return redirect('question', session_id=session_id)

def goback1(request, session_id):
    if not request.user.is_authenticated:
        return redirect('login')
    return redirect('studentquestion1', session_id=session_id)

def goback2(request):
    if not request.user.is_authenticated:
        return redirect('login')
    return redirect('session')

def goback3(request, question_id, session_id):
    if not request.user.is_authenticated:
        return redirect('login')
    return redirect('checkpoint', question_id=question_id, session_id=session_id)

def deactivate_session(request):
    if not request.user.is_authenticated:
        return redirect('login')
    session_id = request.POST['session_id']
    try:
        s = Session.objects.get(session_id =session_id)
        if(s.session_active == 1):
            s.session_active = 0
            s.save()
        return redirect('session')
    except:
        return HttpResponse("Session doesn't exist")

def activate_session(request):
    if not request.user.is_authenticated:
        return redirect('login')
    session_id = request.POST['session_id']
    try:
        s = Session.objects.get(session_id =session_id)
        if(s.session_active == 0):
            s.session_active = 1
            s.save()
        return redirect('session')
    except:
        return HttpResponse("Session doesn't exist")

def delete_session(request):
    if not request.user.is_authenticated:
        return redirect('login')
    session_id = request.POST['session_id']
    try:
        s = Session.objects.get(session_id =session_id)
        Session.objects.filter(session_id=session_id).delete()
        return redirect('session')
    except:
        return HttpResponse("Session doesn't exist")

def statistics(request, question_id, session_id):
    session = get_object_or_404(Session, pk=session_id)
    question = session.question_set.filter(id=question_id)
    x=[]
    y=[]
    y1=[]
    w= 1/1.5
    cl = question[0].checkpoint_set.all()
    c = 0
    for i in cl:
        c +=1 
        y.append(i.votes)
        st = 'Che' + str(c)
        x.append(st)
        pingset = i.ping_set.all()
        y1.append(len(pingset))
        #cl = i.checkpoint_set.all()
        # k = len(cl)
        # for j in range(k):
        #     y.append(cl[j].votes)
        #     st = 'Que' + str(c) + '-Che' + str(j+1)
        #     x.append(st)
    plt.bar(x,y,w, color = "blue")
    plt.xlabel('CheckPoints')
    plt.ylabel('No.of Votes')
    plt.title('Votes Analysis')
    plt.savefig('polls/static/polls/CheckPoint_Bar_Plot1'+str(question_id)+'.png')
    plt.clf()
    plt.bar(x,y1,w, color = "green")
    plt.xlabel('CheckPoints')
    plt.ylabel('No.of Pings')
    plt.title('Pings Analysis')
    plt.savefig('polls/static/polls/CheckPoint_Bar_Plot2'+str(question_id)+'.png')
    plt.clf()
    return render(request, 'polls/statistics.html', {'question' : question[0], 
        's1' :'polls/CheckPoint_Bar_Plot1'+str(question_id)+'.png',
        's2' : 'polls/CheckPoint_Bar_Plot2'+str(question_id)+'.png'
     })





